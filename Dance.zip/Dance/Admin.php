<!DOCTYPE html>
<html>
<head>
	<title>Admin Login| Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <link rel="stylesheet" type="text/css" href="CSS/admin_login.css">
 <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url(Photo/Registration_teacher.JPG);
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 400px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

 </style>


</head>
<body  >

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home </a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			          
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div> 
  

 	
  <div class="col-md-12" align="center" style="margin-top: 40px; margin-bottom: 40px;">
  	 <form method="post" action="admin_login_db.php"  >
  	<div class="Admin_Login">
  	<h3 style="margin-bottom: 40px;">Admin Login</h3>
  	 		<input type="text" name="Admin_Username" id="Admin_Username" placeholder="Username"> 
  			 <input type="password" name="Admin_Password" id="Admin_Password" placeholder="Password"> 
  			 <input type="submit" name="submit" value="Login" class="button"> 
  			
  			
  			 
  		 
  </div>

</form>  
  </div>
 

  
	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>