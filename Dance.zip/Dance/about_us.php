<!DOCTYPE html>
<html>
<head>
	<title>About Us | Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <link rel="stylesheet" type="text/css" href="CSS/team.css">
 <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url("Photo/about-us.PNG");
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 400px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
 
 h2
 {
 	font-size: 50px;
 	letter-spacing: 4px;
 }
 .box
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 5px 10px #888888;
 	margin-bottom: 30px;
 	 


 }
 .box:hover
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 2px 4px #888888;
 	margin-top: 2px;
 	margin-left: 5px;

 }
 .box_content
 {
 	margin-right: 20px;
 	margin-left: 20px;

 }
 </style>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home </a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div> 

<div class="col-md-12" style="margin-top:40px; margin-bottom: 30px;">
	<h2 align="center">Our Staff Members</h2>
</div>
<div class="col-md-3">
	<div class="team" align="center">
		<img src="Photo/Profile_1.PNG" height="100px" width="100px;"  >
		<p class="name"  >Vinsion Roby</p>
		<p class="Experience"  >Experience5+ years</p>
		<p class="Description"  >Vinsion have  got various awards for Zoomba dancing. He is very kneen for teaching students</p>
	</div>
</div>
<div class="col-md-3"> <div class="team" align="center">
		<img src="Photo/Profile_4.PNG" height="100px" width="100px;"  >
		<p class="name"  >John Roy</p>
		<p class="Experience"  >Experience 8+ years</p>
		<p class="Description"  >Kattapa have world record for longest kathak Dance. He is always ready to show off his skills</p>
	</div></div>
<div class="col-md-3"> <div class="team" align="center">
		<img src="Photo/Profile_2.PNG" height="100px" width="100px;"  >
		<p class="name"  >Minnama </p>
		<p class="Experience"  >Experience5+ years</p>
		<p class="Description"  >Minnama was very attacted towards kathak since chilhood. She tooks lessons of dance and now teaches</p>
	</div></div>
<div class="col-md-3"> <div class="team" align="center">
		<img src="Photo/Profile_3.PNG" height="100px" width="100px;"  >
		<p class="name"  >Nelson M</p>
		<p class="Experience"  >Experience5+ years</p>
		<p class="Description"  >She had played very long Garba dance in back few years. She is very eager to teach dance.</p>
	</div></div>

<div class="col-md-12" style="margin-top:40px; margin-bottom: 30px;">
	<h2 align="center">What we Teach</h2>
</div>
<div class="col-md-6">
	<h3>Assam Folk Dance</h3>
	<p style="font-size: 20px;">Bihu is the most popular folk dance of Assam. The people of Assam are very proud of it and rightly so. Except Bhangra no other folk dance in India can compete with the rythmic exuberance of Bihu. Bihu dances performed by young boys and girls characterised by brisk stepping, flinging and flipping of hands and swaying of hips represents youthful passion, reproductive urge and 'Joie-de-vivre'.</p>

</div>
<div class="col-md-6"><img src="Photo/Asam_Folk_Dance.JPG"></div>
 

<div class="col-md-6"><img src="Photo/Bhangra.JPG"></div>
<div class="col-md-6"><h3>Bhangra</h3>
	<p style="font-size: 20px;">Bhangra is a form of dance and music that originated in the Punjab region. Bhangra dance began as a folk dance conducted by Punjabi Sikh farmers to celebrate the coming of the harvest season. The specific moves of Bhangra reflect the manner in which villagers farmed their land. This dance art further became synthesized after the partition of India, when refugees from different parts of the Punjab shared their folk dances with individuals who resided in the regions they settled in. This hybrid dance became Bhangra. </p></div>



<div class="col-md-6">
	<h3>Bharatnatyam</h3>
	<p style="font-size: 20px;">Bharatanatyam is a classical dance form of South India, said to be originated in Thanjavoor of Tamil Nadu. It was known as "Daasiyattam" since performed by Devadasies in temples of Tamil Nadu long ago. The name 'Bharatanatyam' is derived from three basic concepts of Bhava, Raga and Thaala. The modern Bharatanatyam was systematically regularized by well known 'Thanjavoor Brothers', Ponnayya, Chinnayya, Sivanandam and Vativelu.The sequence of the dance performance is 'Alarippu', 'Jathiswaram', 'Sabdam', 'Varnam', 'Padam' and 'Thillana'. After 'Thillana', with a 'Mangala Slokam' the dance program ends. Normally the performance lasts for two to two and half hours.
</p>

</div>
<div class="col-md-6"><img src="Photo/Bharatanatyam.JPG" style="margin-top: 70px;"></div>


 


<div class="col-md-6"><img src="Photo/garba.JPG"></div>
<div class="col-md-6"><h3>Garba</h3>
	<p style="font-size: 20px;">Garba is an Indian form of dance that originated in the Gujarat region. It is more similar to Western folk dance than to the presentational style of Indian classical dances such as bharatanatyam and odissi. The name garba comes from the Sanskrit term Garbha ("womb") and Deep ("a small earthenware lamp"). Many traditional garbas are performed around a central lit lamp. The circular and spiral figures of Garba have similarities to other spiritual dances.</p></div>



<div class="col-md-6">
	<h3>Kathak</h3>
	<p style="font-size: 20px;">Kathakis one of the eight forms of Indian classical dances, originated from northern India and areas which are now part of Pakistan. This dance form traces its origins to the nomadic bards of ancient northern India, known as Kathaks, or storytellers. These bards, performing in village squares and temple courtyards, mostly specialized in recounting mythological and moral tales from the scriptures, and embellished their recitals with hand gestures and facial expressions. It was quintessential theatre, using instrumental and vocal music along with stylized gestures, to enliven the stories

</p>

</div>
<div class="col-md-6"><img src="Photo/Kathak.JPG" style="margin-top: 40px;"></div>





	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>