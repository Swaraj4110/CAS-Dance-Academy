<?php 
 include "connection.php";

  $Username=$_POST['Admin_Username'];
  $Password=$_POST['Admin_Password'];
  // echo $Username, $Password;


	$sql="SELECT * FROM admin Where 1";
$retvalue=mysqli_query($db, $sql);
$result=array();
// echo $result;
// $result=mysqli_fetch_assoc($result);
// if (mysqli_num_rows($result) > 0) {
	
	//Output
	while ($row=mysqli_fetch_assoc($retvalue)) 
	{
		// echo "ID:- ".$row['ID']. "| <b> Name:- </b> ". $row['Username']. "| <b> Password:-</b>  ".$row['Password']."<br>";
		$result[]=$row;

		if ($Username==$row['Username'] and $Password==$row['Password']) 
		{
			session_start();
			echo "USER found";
			$_SESSION['A_Name']=$row['Name'];
		 	$_SESSION['Success']='WELCOME';
		 	header('location:adminpanal.php');

		}
	}
	
	echo "Invalid Credential";
	// echo $name;
 	// echo $password;
	$list=$result;	
// else
// {
// 	echo "0 result";
// }
	$list=$result;	
 ?><!-- $_SESSION['A_Name']=$row['Name'];
		 	$_SESSION['Success']='WELCOME';
		 	header('location:adminpanal.php'); -->