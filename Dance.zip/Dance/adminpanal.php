<?php 
session_start();
include 'connection.php';
	
	// echo "Hello";
if (isset($_SESSION['A_Name'])) 
		{
			// echo $_SESSION['success'], $_SESSION['username'];
			$username=$_SESSION['A_Name']; 
		}
		else
		{
			echo "Invalid Session!!! Please Login to view this page!!!";
      
      
			exit();
		}


 ?>
 <?php 


$sql="SELECT * FROM teacher Where 1";
$retvalue=mysqli_query($conn, $sql);
$result=array();
// echo $result;
// $result=mysqli_fetch_assoc($result);
// if (mysqli_num_rows($result) > 0) {
	
	//Output
	while ($row=mysqli_fetch_assoc($retvalue)) 
	{
		// echo "ID:- ".$row['ID']. "| <b> Subject:- </b> ". $row['Subject']. "| <b> Question:-</b>  ".$row['Question']. " |<b>Answer:-</b>".$row['Answer']."<br>";
		$result[]=$row;
	}
	$list=$result;

// else
// {
// 	echo "0 result";
// }


  ?>
 <!DOCTYPE html>
<html>
<head>
	<title>Admin Panal| Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <link rel="stylesheet" type="text/css" href="CSS/Admin_Welcome.css">
 <link rel="stylesheet" type="text/css" href="CSS/table.css">
 <link rel="stylesheet" type="text/css" href="CSS/logout.css">
  <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url(Photo/Data_Banner.JPG);
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 400px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

 </style>


</head>
<body  >

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home </a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			          
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div> 
  

 	<div class="col-md-6">
 		<div class="Admin_Welcome">
 			<?php echo "WELCOME $username"; ?>
 		</div>
 	</div>
 	<div class="col-md-6" align="right" style="margin-top: 30px;">
 		<div class="logout">
 			<a href="logout.php">Logout</a>
 		</div>
 	</div>
 	<div class="col-md-12">
 		<div class="Students_Data_Link"><a class="a" href="student_registration_data.php">View Students Data</a></div>
 	</div>	
<div class="col-md-12" style=" z-index: 10; margin-top: 20px;" width="100%" align="center"><br><br><br><br>

     <h1 align="center"><font>Teacher Data</font></h1>
 <table border="1px" class="table"  >
  <thead align="center" >
    
    <th>No</th>
    <th>ID</th>
    <th>Name </th>
    <th>Email</th>
    <th>Contact</th>
    <th>Experience</th>
     
  </thead>
  <tbody>
    <?php $i=1; foreach ($list as $list_row): ?>
      <tr>
      <td align="center" >
        <?php echo $i ?>
      </td>
      <td align="center">
        <?php echo $list_row['ID'] ?>
      </td>
      <td  >
        <?php echo $list_row['Name'] ?>
      </td>
       
      <td>
        <?php echo $list_row['Email'] ?>
      </td>
       
      <td>
        <?php echo $list_row['Contact'] ?>
      </td>
      <td>
        <?php echo $list_row['Experience'] ?>
      </td>
      
    </tr>
    <?php $i++; endforeach ?>
    
  </tbody>
 </table>
</div>
 

  
	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>