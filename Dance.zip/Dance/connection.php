<?php 

$db=mysqli_connect("localhost","root","","swaraj_dancing");
	if ($db->connect_error) {
		echo "Connection failed to database.. Please try again later...";
	}
	else
	{
		// echo "Connection succesfull";
	}

	$server="localhost";
	$user="root";
	$password="";
	$dbname="swaraj_dancing";
	$conn= mysqli_connect($server, $user, $password, $dbname);
if (!$conn) {
	die("Conncection failed".mysqli_conncet_error());
			// header('location:http://pawankalecse.epizy.com/dberror.php');

}
else
{
	// echo "<br>"."Conncection Succesful...<br>";
}
 ?>
