<!DOCTYPE html>
<html>
<head>
	<title>Contact Us | Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <link rel="stylesheet" type="text/css" href="CSS/team.css">
 <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url("Photo/Contact_Us.JPG");
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 400px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
 
 h2
 {
 	font-size: 50px;
 	letter-spacing: 4px;
 }
 .box
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 5px 10px #888888;
 	margin-bottom: 30px;
 	 


 }
 .box:hover
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 2px 4px #888888;
 	margin-top: 2px;
 	margin-left: 5px;

 }
 .box_content
 {
 	margin-right: 20px;
 	margin-left: 20px;

 }
 </style>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home </a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			          
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div> 
 
 <div class="col-md-5" align="center" style="font-size: 20px;">
 		<img src="Photo/mobile.PNG" height="80px" width="80px"> <br>
 				 9146493850 - Swaraj <br>9130710925 - Ankita <br>7588733936 - Chaitali <hr> 
 		<img src="Photo/email.PNG" height="80px" width="80px"> <br>				swarajgaikwadofficial@gamil.com <br> ankitamathpati@gmail.com <br> sonawanechaitali23@gmail.com<hr>
 		<img src="Photo/address.PNG" height="60px" width="80px"><br> <br>  
 		<p style="font-size: 20px">Building NO 5<br>  KNP Raod 6<br>Pune</div></p>
 <div class="col-md-7" style="border:1px solid black;">
 	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7566.283344729366!2d73.86238617162121!3d18.522498949631235!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c066f80ca1df%3A0x2bef7438a1bfb61d!2sTrishundha%20Ganpati%20Mandir!5e0!3m2!1sen!2sin!4v1604598110241!5m2!1sen!2sin" width="640" height="600" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
 	
 </div>


	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>