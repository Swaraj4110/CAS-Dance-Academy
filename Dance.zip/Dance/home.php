<!DOCTYPE html>
<html>
<head>
	<title>Home | Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url("Photo/Slider_Image.jpg");
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 600px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
 p
 {
 	/*margin-right: 150px;
 	margin-left: 150px;*/
 	padding: 50px;
 	border-right: 4px solid yellow;
 	border-left: 4px solid yellow;
 	border-radius: 20px;
 	margin-bottom: 30px;

 }
 h2
 {
 	font-size: 50px;
 	letter-spacing: 4px;
 }
 .box
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 5px 10px #888888;
 	margin-bottom: 30px;
 	 


 }
 .box:hover
 {
 	border:1px solid black;
 	padding-top: 40px;
 	padding-bottom: 40px;
 	padding-right: 20px;
 	padding-left: 20px;
 	box-shadow: 2px 4px #888888;
 	margin-top: 2px;
 	margin-left: 5px;

 }
 .box_content
 {
 	margin-right: 20px;
 	margin-left: 20px;

 }
 </style>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="student_registration.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			          
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div>
<!-- ADmin Login Shortkey is here -->
<div class="col-md-2"><a href="Admin.php" accesskey="a"></a></div>


<div class="col-md-8">
	<h2 align="center" style="margin:40px;">C.A.S. Dance Academy</h2>
	<p align="center">
		 We have established a Dancing academy with the aim of finding hidden talents from youth and youngesters and give them appropriate knowledge for growing and shining their skills all over the world. We have started to work in 1999 since the date we have more than 1000+ students entertaing all over world with their skills. <br>
		 We are proud to say that we give oppurtunites to studetns with minimum cost as well as we adopt at least 10 students per year and teach them dancing skills to earn enought to survive for them. Also we have collabration with different firms which provides us financial support for such students. We are looking forward to more and more students who want to learn but thier financial background is obstalce for them. We invite them reach at us.
	</p>
</div>
<div class="col-md-2"></div>

<div class="col-md-4">
	<div class="box">

		<img src="Photo/Dance_icon.PNG" height="50px" width="50px" style="margin-left:40%;">
		<h4 align="center">What We teach</h4>
		<nav class="box_content" align="center">We teach variout types of dance under one roof. We have Manipuri, Lavni, Kathakalli, Khathak and much more varitey in dancing.</nav>
	</div>
</div>
<div class="col-md-4"><div class="box">

		<img src="Photo/coreographer.PNG" height="50px" width="50px" style="margin-left:40%;">
		<h4 align="center">Best Coreograhpers</h4>
		<nav class="box_content" align="center">We have best coreographer to teach you variety of dance who are best in their own. We also provide online teaching facility to students </nav>
	</div></div>
<div class="col-md-4"><div class="box">

		<img src="Photo/admission.PNG" height="50px" width="50px" style="margin-left:40%;">
		<h4 align="center">Enroll Today</h4>
		<nav class="box_content" align="center">We have limites seats to give personal attention to each stduent. Confirm your admission today to ensure your place.</nav>
	</div></div>


 


	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>