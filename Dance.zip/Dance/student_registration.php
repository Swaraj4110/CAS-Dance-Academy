<!DOCTYPE html>
<html>
<head>
	<title>Student Registration | Dance </title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <link rel="stylesheet" type="text/css" href="CSS/menu_bar_home_page.css">
 <link rel="stylesheet" type="text/css" href="CSS/footer.css">
 <link rel="stylesheet" type="text/css" href="CSS/Stduent_registratio_form.css">
 <!-- <link rel="stylesheet" type="text/css" href="CSS/student_registration.css"> -->
 <style type="text/css">
 	 
.parallax {
  /* The image used */
  background-image: url(Photo/Registration_teacher.JPG);
  margin-left: -120px;
  margin-right: -120px;
  /* Set a specific height */
  min-height: 400px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.student_registration
{
	/*background-color: blue;*/
}
input
{
	margin: 5px;
	width: 20em;
	border-radius: 20px;
	height: 35px;
	border: 2px solid green;
	margin-left: 2px;
	background-color: transparent;

}
input[type=submit]
{
	background-color: #ddd;
	border:none;
}
.student_registration
{
	box-shadow: 10px 10px 10px 10px #ddd;
	padding-top: 30px;
}
::placeholder
{
   color: #407342;
   padding-left: 5px;
}
 </style>
</head>
<body  >

<div class="container">
	<div class="row">
		<div class="col-md-12">	
			<!-- Menu bar is here -->
			<nav class="parallax">
<div style="position:absolute; color: white; margin-left:90px;" class="menu">
				<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
					 
		  <a class="navbar-brand" href="#" >C.A.S. Dance Academy	</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNav">
		    <ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="home.php">Home </a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="about_us.php">About Us <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="contact_us.php">Contact Us</a>
		      </li>
		     <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          Join Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: black;">
			          <a class="dropdown-item" href="teacher_registration.php"><font color="black">As Teacher</font></a>
			          <a class="dropdown-item" href="student_registration.php"><font color="black">As Student</font></a>
			          
			        </div>
		      </li>
		    </ul>
		  </div> 

		</nav>
</div>
</nav>
		<!-- Menu bar ends here -->
</div> 
  
 <form method="post" action="student_registration_db.php"  >
 	
  <div class="col-md-12" align="center" style="margin-top: 30px; margin-bottom: 40px; text-align: center;">
  	<div class="student_registration">
  	<h3 style="margin-bottom: 40px;"> Student Registration Form</h3>
  	<div class="container">
  		<div class="row">
  			
  			<div class="col-md-12" align="center" style="font-size: 30px; margin-bottom: 30px;"> Personal Details</div>
  			<div class="col-md-4"><input type="text" name="student_Lname" id="student_Lname" placeholder="Last Name" class="inputt"  ></div>
  			<div class="col-md-4"><input type="text" name="student_Fname" id="student_Fname" placeholder="First Name"></div>
  			<div class="col-md-4"><input type="text" name="student_Mname" id="student_Mname" placeholder="Middle Name"></div>
  			<div class="col-md-12" style="font-size: 30px; margin-bottom: 30px; margin-top: 30px"> Contact Details</div>
  			<div class="col-md-4"><input type="email" name="student_email" id="student_email" placeholder="Email"></div>
  			<div class="col-md-4"><input type="text" name="student_contact" id="student_contact" placeholder="Contact"></div>
  			<div class="col-md-4"><input type="text" name="student_contact_home" id="student_contact_home" placeholder="Home Contact"></div>
  			<div class="col-md-12" style="font-size: 30px; margin-bottom: 30px; margin-top: 30px"> Address Details</div>
  			<div class="col-md-4"><input type="text" name="student_city" id="student_city" placeholder="City"></div>
  			<div class="col-md-4"><input type="text" name="student_District" id="student_District" placeholder="District"></div>
  			<div class="col-md-4"><input type="text" name="student_State" id="student_State" placeholder="State"></div>
  			<div class="col-md-6" style="margin-top: 30px;"><input type="text" name="student_Country" id="student_Country" placeholder="Country"></div>
  			<div class="col-md-6" style="margin-top: 30px;"><input type="text" name="student_PIN" id="student_PIN" placeholder="PIN code"></div>
  			<div class="col-md-12" style="margin-top: 30px;"><textarea rows="7" cols="50" placeholder="Why You want to join us?" name="Student_Reason" style="margin: 5px;
	width: auto;
	border-radius: 20px;
	height:auto;
	border: 2px solid green;
	margin-left: 2px;"></textarea></div>
  			<div class="col-md-12"><input type="submit" name="submit" value="Register" class="button"></div>
  			
  			
  			 
  		</div>
  	</div>
  </div>


  </div>
 
</form>  
	</div>
</div>

<footer class="footer" align="center">&#169; 2020 All rights reserved | C.A.S. Dance Academy</footer>
</body>
</html>