<?php 

include "connection.php";
$F_Name=$_POST['student_Fname'];
$M_Name=$_POST['student_Mname'];
$L_Name=$_POST['student_Lname'];
$Email=$_POST['student_email'];
$Contact=$_POST['student_contact'];
$Telephone=$_POST['student_contact_home'];
$City=$_POST['student_city'];
$District=$_POST['student_District'];
$State=$_POST['student_State'];
$Country=$_POST['student_Country'];
$PIN=$_POST['student_PIN'];
$Reason=$_POST['Student_Reason'];
 

$sql = "INSERT INTO student (F_Name, M_Name, L_Name, Email, Contact, Telephone, City, District, State, Country, PIN , Reason)
VALUES ('$F_Name', '$M_Name', '$L_Name', '$Email', '$Contact','$Telephone', '$City', '$District', '$State', '$Country', '$PIN', '$Reason' )";
 
 
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Confirmation</title>
 </head>
 <body>
 		<?php 
 		if ($db->query($sql)==TRUE){
	// echo "Data Added succesfully";
    // the message
    // $msg = "First line of text\nSecond line of text";

    // use wordwrap() if lines are longer than 70 characters
    // $msg = wordwrap($msg,70);

    // send email
    // wp_mail("pawankalecse@gmail.com","My subject",$msg);
        // header('location:http://pawankalecse.epizy.com/index.php');
        
    } ?>
    We have received your request we will respond you soon........

    <?php 
 
     ?>
 </body>
 </html>