<?php 

include "connection.php";
$name=$_POST['teacher_name'];
$email=$_POST['teacher_email'];
$contact=$_POST['teacher_contact'];
$experience=$_POST['teacher_experience'];

$sql="INSERT into teacher(Name, Email, Contact, Experience ) values('$name', '$email', '$contact', '$experience')";
// $retvalue="mysqli_query($sql)";
 
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Confirmation</title>
 </head>
 <body>
 		<?php 
 		if ($db->query($sql)==TRUE){
	// echo "Data Added succesfully";
    // the message
    // $msg = "First line of text\nSecond line of text";

    // use wordwrap() if lines are longer than 70 characters
    // $msg = wordwrap($msg,70);

    // send email
    // wp_mail("pawankalecse@gmail.com","My subject",$msg);
        // header('location:http://pawankalecse.epizy.com/index.php');
        
    }
    else{
        echo "Error Occured";
    } ?>
    
    We have received your request we will respond you soon........

    <?php 
 
     ?>

 </body>
 </html>